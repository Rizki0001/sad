
const help = (prefix) => { 
	return `            	
┏━━━━°❀ ❬ RIZKIBOT ❭ ❀°━━━━┓
┃╔═══════════════════╗
┏❉ *${prefix}owner*
┣❉ *${prefix}donasi*
┗❉ *${prefix}info*
┃╚═══════════════════╝
┣━━━━°❀ ❬ 𝗠𝗔𝗞𝗘𝗥 ❭ ❀°━━━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}sticker*
┃╠➥ *${prefix}sticker nobg*
┃╠➥ *${prefix}tsticker*
┃╠➥ *${prefix}nulis*
┃╠➥ *${prefix}logowolf*
┃╚═══════════════════╝
┣━━━━°❀ ❬ 𝙈𝙀𝘿𝙄𝘼 ❭ ❀°━━━━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}tts*
┃╠➥ *${prefix}tiktok*
┃╠➥ *${prefix}meme*
┃╠➥ *${prefix}memeindo*
┃╠➥ *${prefix}nsfwloli* 
┃╠➥ *${prefix}ocr*
┃╠➥ *${prefix}neko*
┃╠➥ *${prefix}randomanime*
┃╠➥ *${prefix}loli*
┃╠➥ *${prefix}waifu*
┃╚═══════════════════╝
┣━━━°❀ ❬ 𝘿𝙊𝙒𝙉𝙇𝙊𝘼𝘿 ❭ ❀°━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}ytmp3*
┃╠➥ *${prefix}ytmp4*
┃╚═══════════════════╝
┣━━━━°❀ ❬ 𝙂𝙍𝙊𝙐𝙋 ❭ ❀°━━━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}add* [62xxx]
┃╠➥ *${prefix}kick* [tag]
┃╠➥ *${prefix}setpp*
┃╠➥ *${prefix}tagme*
┃╠➥ *${prefix}demote* [tag]
┃╠➥ *${prefix}promote* [tag]
┃╠➥ *${prefix}grup* [buka/tutup]
┃╠➥ *${prefix}welcome* [1/0]
┃╠➥ *${prefix}nsfw* [1/0]
┃╠➥ *${prefix}simih* [1/0]
┃╚═══════════════════╝
┣━━━━°❀ ❬ 𝙊𝙒𝙉𝙀𝙍 ❭ ❀°━━━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}bc* 
┃╠➥ *${prefix}clearall*
┃╠➥ *${prefix}setprefix*
┃╠➥ *${prefix}leave*
┃╠➥ *${prefix}clone* [tag]
┃╚═══════════════════╝
┣━━━━━°❀ ❬ 𝙎𝙋𝘼𝙈 ❭ ❀°━━━━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}spamsms*
┃╠➥ *${prefix}spamcall*
┃╠➥ *${prefix}spamgmail*
┃╚═══════════════════╝
┣━━━━°❀ ❬ 𝙊𝙏𝙃𝙀𝙍 ❭ ❀°━━━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}ytsearch*
┃╠➥ *${prefix}listadmin*
┃╠➥ *${prefix}blocklist*
┃╠➥ *${prefix}wait*
┃╠➥ *${prefix}nama*
┃╠➥ *${prefix}map*
┃╠➥ *${prefix}qrcode*
┃╠➥ *${prefix}tiktokstalk*
┃╠➥ *${prefix}shortlink*
┃╠➥ *${prefix}url2img*
┃╠➥ *${prefix}alay*
┃╠➥ *${prefix}quotes*
┃╠➥ *${prefix}bucin*
┃╠➥ *${prefix}wiki*
┃╠➥ *${prefix}wikien*
┃╚═══════════════════╝
┣━━━━°❀ ❬ 𝙎𝙊𝙐𝙉𝘿 ❭ ❀°━━━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}tapi*
┃╚═══════════════════╝
┣━━━━━━━━━━━━━━━━━━━━━⊱
┃┌───────────────────┐
┃│╔══╗
┃│╚║║╝
┃│╔║║╗
┃│╚══╝
┃├───────────────────┐
┃└───────────────────┘
┣━━━━━━━━━━━━━━━━━━━━━┓
┃  𝗣𝗢𝗪𝗘𝗥𝗘𝗗 𝗕𝗬 RIZKIBOT 𝗜𝗗   
┗━━━━━━━━━━━━━━━━━━━━━┛`
}

exports.help = help

 